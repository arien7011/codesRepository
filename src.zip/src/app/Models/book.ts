export interface book
{
   bookid:number;
   isbn:string,
   title:string,
   author:string,
   description:string,
   password:string,
   publisher:string;
}